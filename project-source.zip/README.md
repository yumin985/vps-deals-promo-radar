# vps-deals

An English-language directory of VPS plans and promotions collected from providers' public official pages. Each displayed price links to its source and includes the time it was fetched. This first version has no affiliate links; links are direct provider links.

## Build locally

```powershell
python scraper.py
python build.py
```

The build writes the static site to `site/`. It uses only the Python standard library. Provider sources and the canonical site URL are read from `.ilang/site.ilang`.

## Automated refresh

GitHub Actions is configured to attempt a refresh every six hours. It checks each origin's `robots.txt`, reads public pages only, and commits changed data and generated pages. Sites that block or do not expose verifiable structured offer data are skipped; no price is guessed.

## Cloudflare Pages

Use the Git-connected Pages build command `python build.py` and output directory `site`. The canonical URL in `.ilang/site.ilang` must match the actual Pages project URL or custom domain.

Site rules are described with the I-Lang protocol in `.ilang/site.ilang`; protocol information: [ilang.ai](https://ilang.ai).
